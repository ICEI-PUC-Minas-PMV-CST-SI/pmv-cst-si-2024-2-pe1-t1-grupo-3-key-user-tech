﻿using System;
using System.IO;
using System.Management;
using System.Security.Principal;
using System.Text;

namespace InventoryApp
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Inventário do Sistema ===");
                Console.WriteLine("1. Informações de Hardware");
                Console.WriteLine("2. Informações de Software (Sistema Operacional)");
                Console.WriteLine("3. Informações de Hardware e Software");
                Console.WriteLine("4. Exportar Resultado para Arquivo");
                Console.WriteLine("5. Sair");
                Console.Write("Escolha uma opção: ");
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        GetInventory("Hardware");
                        break;
                    case "2":
                        GetInventory("Software");
                        break;
                    case "3":
                        GetInventory("All");
                        break;
                    case "4":
                        ExportInventory();
                        break;
                    case "5":
                        Console.WriteLine("Saindo...");
                        return;
                    default:
                        Console.WriteLine("Opção inválida. Pressione qualquer tecla para tentar novamente...");
                        Console.ReadKey();
                        break;
                }
            }
        }

        static void GetInventory(string option, StringBuilder output = null)
        {
            try
            {
                output ??= new StringBuilder();

                Console.Clear();

                // Verificar privilégios
                if (!IsUserAdministrator())
                {
                    string warning = "Atenção: Você não está executando o programa como administrador. Algumas informações podem estar indisponíveis.\n";
                    Console.WriteLine(warning);
                    output.AppendLine(warning);
                }

                // Informações de Hardware
                if (option == "Hardware" || option == "All")
                {
                    string header = "\n=== Informações de Hardware ===\n";
                    Console.WriteLine(header);
                    output.AppendLine(header);

                    DisplayHardwareInfo("Win32_ComputerSystem", output, "Manufacturer", "Model", "SystemType", "TotalPhysicalMemory");
                    DisplayHardwareInfo("Win32_Processor", output, "Name", "NumberOfCores", "MaxClockSpeed", "Description");
                    DisplayHardwareInfo("Win32_PhysicalMemory", output, "Manufacturer", "Capacity", "Speed", "PartNumber");
                    DisplayHardwareInfo("Win32_DiskDrive", output, "Model", "Size", "MediaType", "Status");

                    string footer = "--- Fim das Informações de Hardware ---\n";
                    Console.WriteLine(footer);
                    output.AppendLine(footer);
                }

                // Informações de Software
                if (option == "Software" || option == "All")
                {
                    string header = "\n=== Informações de Software (Sistema Operacional) ===\n";
                    Console.WriteLine(header);
                    output.AppendLine(header);

                    // Exibir as informações do sistema operacional
                    DisplaySoftwareInfo("Win32_OperatingSystem", output, "Caption", "Version", "InstallDate", "LastBootUpTime");

                    // Exibir o SystemType (arquitetura do sistema)
                    DisplayHardwareInfo("Win32_ComputerSystem", output, "SystemType");

                    string footer = "\n--- Fim das Informações de Software ---\n";
                    Console.WriteLine(footer);
                    output.AppendLine(footer);
                }

                Console.WriteLine("\nExecução concluída. Pressione qualquer tecla para voltar ao menu...");
                Console.ReadKey();
            }
            catch (UnauthorizedAccessException)
            {
                string error = "Erro: Permissões insuficientes para acessar as informações solicitadas.";
                Console.WriteLine(error);
                output?.AppendLine(error);
                Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                string error = $"Erro: {ex.Message}";
                Console.WriteLine(error);
                output?.AppendLine(error);
                Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                Console.ReadKey();
            }
        }

        static void DisplayHardwareInfo(string wmiClass, StringBuilder output, params string[] properties)
        {
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher($"SELECT * FROM {wmiClass}");
                ManagementObjectCollection queryCollection = searcher.Get();

                foreach (ManagementObject m in queryCollection)
                {
                    string sectionHeader = "\n--- " + wmiClass.Replace("Win32_", "").Replace("_", " ") + " ---";
                    Console.WriteLine(sectionHeader);
                    output.AppendLine(sectionHeader);

                    foreach (var property in properties)
                    {
                        try
                        {
                            var value = m[property] ?? "Não disponível";

                            // Verificação de SystemType (x64-based PC) como prioridade
                            if (property == "SystemType")
                            {
                                value = m["SystemType"] ?? "Não disponível";
                                if (string.IsNullOrEmpty(value.ToString()))
                                {
                                    value = "Não identificado";
                                }
                            }

                            // Conversão de capacidade para GB (RAM, Discos, etc.)
                            if (property == "Capacity" || property == "Size" || property == "TotalPhysicalMemory")
                            {
                                value = ConvertBytesToGB(value.ToString());
                            }

                            string line = $"{property,-25}: {value}";
                            Console.WriteLine(line);
                            output.AppendLine(line);
                        }
                        catch
                        {
                            string errorLine = $"{property,-25}: Informação não disponível";
                            Console.WriteLine(errorLine);
                            output.AppendLine(errorLine);
                        }
                    }
                    string separator = new string('-', 50);
                    Console.WriteLine(separator);
                    output.AppendLine(separator);
                }
            }
            catch (UnauthorizedAccessException)
            {
                string error = $"Permissão insuficiente para acessar informações de {wmiClass}.";
                Console.WriteLine(error);
                output.AppendLine(error);
            }
        }

        static void DisplaySoftwareInfo(string wmiClass, StringBuilder output, params string[] properties)
        {
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher($"SELECT * FROM {wmiClass}");
                ManagementObjectCollection queryCollection = searcher.Get();

                foreach (ManagementObject m in queryCollection)
                {
                    string sectionHeader = "\n--- " + wmiClass.Replace("Win32_", "").Replace("_", " ") + " ---";
                    Console.WriteLine(sectionHeader);
                    output.AppendLine(sectionHeader);

                    foreach (var property in properties)
                    {
                        try
                        {
                            var value = m[property] ?? "Não disponível";

                            // Formatar datas específicas
                            if (property == "InstallDate" || property == "LastBootUpTime")
                            {
                                value = FormatWmiDate(value.ToString());
                            }

                            // Adicionar um pequeno destaque para as informações
                            string formattedLine = $"{property,-25}: {value}";
                            Console.WriteLine(formattedLine);
                            output.AppendLine(formattedLine);
                        }
                        catch
                        {
                            string errorLine = $"{property,-25}: Informação não disponível";
                            Console.WriteLine(errorLine);
                            output.AppendLine(errorLine);
                        }
                    }
                    string separator = new string('-', 50);
                    Console.WriteLine(separator);
                    output.AppendLine(separator);
                }
            }
            catch (UnauthorizedAccessException)
            {
                string error = $"Permissão insuficiente para acessar informações de {wmiClass}.";
                Console.WriteLine(error);
                output.AppendLine(error);
            }
        }

        static string ConvertBytesToGB(string byteValue)
        {
            try
            {
                if (double.TryParse(byteValue, out double bytes))
                {
                    double gb = Math.Round(bytes / (1024 * 1024 * 1024), 2);
                    return $"{gb} GB";
                }
                return "Não disponível";
            }
            catch
            {
                return "Não disponível";
            }
        }

        static string FormatWmiDate(string wmiDate)
        {
            if (string.IsNullOrEmpty(wmiDate) || wmiDate.Length < 14)
                return "Formato de data inválido";

            try
            {
                int year = int.Parse(wmiDate.Substring(0, 4));
                int month = int.Parse(wmiDate.Substring(4, 2));
                int day = int.Parse(wmiDate.Substring(6, 2));
                int hour = int.Parse(wmiDate.Substring(8, 2));
                int minute = int.Parse(wmiDate.Substring(10, 2));
                int second = int.Parse(wmiDate.Substring(12, 2));

                DateTime date = new DateTime(year, month, day, hour, minute, second);
                return date.ToString("yyyy-MM-dd HH:mm:ss");
            }
            catch
            {
                return "Data inválida";
            }
        }

        static bool IsUserAdministrator()
        {
            try
            {
                var principal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch
            {
                return false;
            }
        }

        static void ExportInventory()
        {
            try
            {
                StringBuilder output = new StringBuilder();
                Console.WriteLine("Exportando informações...");

                GetInventory("All", output);

                string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "inventory.txt");

                File.WriteAllText(filePath, output.ToString());
                Console.WriteLine($"Arquivo exportado com sucesso para: {filePath}");
                Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao exportar: {ex.Message}");
                Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                Console.ReadKey();
            }
        }
    }
}
